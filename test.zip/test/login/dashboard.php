<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>2MTV - Assistance</title>
<style>
  .sidebar-group-links { overflow:hidden; max-height:600px; transition: max-height .25s ease; }
.sidebar-group-links.collapsed { max-height:0; }
.chevron { transition: transform .2s ease; }
.chevron.rotated { transform: rotate(-90deg); }
:root {
  --bg-primary:#0a0a0e; --bg-sidebar:#0c0c11; --bg-card:#131319; --bg-input:#1a1a22;
  --border-color:#26262f; --text-primary:#ffffff; --text-secondary:#8b8b96; --text-muted:#5c5c66;
  --accent:#f0a52c; --accent-hover:#ffb84d;
  --status-open:#4a90e2; --status-progress:#f0a52c; --status-resolved:#4caf50; --status-closed:#6b6b76;
  --priority-low:#4caf50; --priority-medium:#f0c929; --priority-high:#f0842c; --priority-critical:#e94b4b;
  --radius:10px;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg-primary); color:var(--text-primary); font-family:'Segoe UI',Roboto,Arial,sans-serif; display:flex; min-height:100vh; }

/* SIDEBAR */
.sidebar { width:260px; background:var(--bg-sidebar); border-right:1px solid var(--border-color); min-height:100vh; padding:20px 0; flex-shrink:0; }
.sidebar-group-title { display:flex; align-items:center; justify-content:space-between; padding:10px 20px; font-size:12px; font-weight:700; letter-spacing:1px; color:var(--text-secondary); cursor:pointer; }
.sidebar-group-title svg { width:14px; height:14px; }
.sidebar-link { display:flex; align-items:center; gap:10px; padding:10px 20px 10px 44px; color:var(--text-secondary); text-decoration:none; font-size:14px; border-left:3px solid transparent; transition:.15s; cursor:pointer; background:none; border-top:none; border-right:none; border-bottom:none; width:100%; text-align:left; }
.sidebar-link:hover { color:var(--text-primary); background:rgba(255,255,255,.03); }
.sidebar-link.active { color:var(--text-primary); border-left:3px solid var(--accent); background:rgba(240,165,44,.08); }
.sidebar-link svg { width:16px; height:16px; flex-shrink:0; }
.sidebar-divider { border:none; border-top:1px solid var(--border-color); margin:14px 20px; }

/* MAIN LAYOUT */
.main-content { flex:1; display:flex; flex-direction:column; min-width:0; }
.topbar { display:flex; align-items:center; justify-content:space-between; padding:14px 24px; border-bottom:1px solid var(--border-color); }
.topbar-left, .topbar-right { display:flex; align-items:center; gap:14px; }
.topbar-icon-btn { background:none; border:none; color:var(--text-secondary); cursor:pointer; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:8px; }
.topbar-icon-btn:hover { background:rgba(255,255,255,.05); color:var(--text-primary); }
.badge-system { background:rgba(240,165,44,.12); color:var(--accent); border:1px solid rgba(240,165,44,.3); padding:6px 14px; border-radius:8px; font-size:13px; font-weight:600; display:flex; align-items:center; gap:6px; }
.btn-logout { background:var(--bg-card); border:1px solid var(--border-color); color:var(--text-primary); padding:8px 14px; border-radius:8px; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:6px; }
.avatar { width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,#f0a52c,#e94b4b); display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:700; }
.page-body { padding:28px 32px; flex:1; }
<!-- ==================== PLACEHOLDER (Administration / Setup) ==================== -->
<section class="view" id="view-placeholder">
  <div class="page-header">
    <div class="page-header-left"><h1 id="placeholder-title">—</h1></div>
  </div>
  <div class="card">
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
      <h3>Coming soon</h3>
      <p>Cette section n'est pas encore développée</p>
    </div>
  </div>
</section>
/* VIEWS */
.view { display:none; }
.view.active { display:block; }

/* HEADER / TOOLBAR */
.page-header { display:flex; align-items:center; justify-content:space-between; background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius); padding:18px 22px; margin-bottom:18px; flex-wrap:wrap; gap:12px; }
.page-header-left { display:flex; align-items:center; gap:12px; }
.page-header h1 { font-size:20px; font-weight:800; }
.pill { background:var(--bg-input); border:1px solid var(--border-color); padding:4px 12px; border-radius:20px; font-size:13px; color:var(--text-secondary); }
.header-actions { display:flex; gap:10px; flex-wrap:wrap; }

/* BUTTONS */
.btn { display:inline-flex; align-items:center; gap:8px; padding:9px 16px; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; border:1px solid var(--border-color); background:var(--bg-card); color:var(--text-primary); transition:.15s; text-decoration:none; }
.btn:hover { background:rgba(255,255,255,.05); }
.btn svg { width:15px; height:15px; }
.btn-primary { background:var(--accent); border-color:var(--accent); color:#14100a; }
.btn-primary:hover { background:var(--accent-hover); }
.btn-danger { background:rgba(233,75,75,.1); border-color:rgba(233,75,75,.4); color:#e94b4b; }
.btn-danger:hover { background:rgba(233,75,75,.2); }
.btn-sm { padding:6px 10px; font-size:12px; }

/* TOOLBAR */
.toolbar { display:flex; gap:12px; background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius); padding:14px; margin-bottom:18px; flex-wrap:wrap; }
.search-input { flex:1; min-width:220px; display:flex; align-items:center; gap:10px; background:var(--bg-input); border:1px solid var(--border-color); border-radius:8px; padding:9px 14px; }
.search-input svg { width:16px; height:16px; color:var(--text-muted); }
.search-input input { background:none; border:none; outline:none; color:var(--text-primary); font-size:13px; width:100%; }
.search-input input::placeholder { color:var(--text-muted); }
select, .form-select { background:var(--bg-input); border:1px solid var(--border-color); color:var(--text-primary); padding:9px 14px; border-radius:8px; font-size:13px; outline:none; cursor:pointer; }

/* CARD / TABLE */
.card { background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius); padding:20px; }
.data-table { width:100%; border-collapse:collapse; }
.data-table th { text-align:left; font-size:12px; text-transform:uppercase; letter-spacing:.5px; color:var(--text-muted); padding:10px 14px; border-bottom:1px solid var(--border-color); }
.data-table td { padding:14px; font-size:14px; border-bottom:1px solid var(--border-color); }
.data-table tr:last-child td { border-bottom:none; }
.data-table tr:hover td { background:rgba(255,255,255,.02); }
.row-actions { display:flex; gap:8px; }

/* BADGES */
.badge { display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.badge::before { content:''; width:7px; height:7px; border-radius:50%; background:currentColor; }
.status-open { background:rgba(74,144,226,.12); color:var(--status-open); }
.status-in-progress { background:rgba(240,165,44,.12); color:var(--status-progress); }
.status-resolved { background:rgba(76,175,80,.12); color:var(--status-resolved); }
.status-closed { background:rgba(107,107,118,.12); color:var(--status-closed); }
.priority-low { background:rgba(76,175,80,.12); color:var(--priority-low); }
.priority-medium { background:rgba(240,201,41,.12); color:var(--priority-medium); }
.priority-high { background:rgba(240,132,44,.12); color:var(--priority-high); }
.priority-critical { background:rgba(233,75,75,.12); color:var(--priority-critical); }

/* EMPTY STATE */
.empty-state { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:60px 20px; color:var(--text-secondary); text-align:center; }
.empty-state svg { width:40px; height:40px; margin-bottom:14px; color:var(--text-muted); }
.empty-state h3 { color:var(--text-primary); font-size:17px; margin-bottom:6px; }
.empty-state p { font-size:13px; color:var(--text-muted); }

/* FORMS */
.form-group { margin-bottom:18px; }
.form-group label { display:block; font-size:13px; font-weight:600; color:var(--text-secondary); margin-bottom:8px; }
.form-group input, .form-group select, .form-group textarea { width:100%; background:var(--bg-input); border:1px solid var(--border-color); color:var(--text-primary); padding:11px 14px; border-radius:8px; font-size:14px; outline:none; font-family:inherit; }
.form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color:var(--accent); }
.form-group textarea { resize:vertical; min-height:110px; }
.form-row { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
.form-actions { display:flex; justify-content:flex-end; gap:10px; margin-top:6px; }

/* STATS */
.stats-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin-bottom:20px; }
.stat-card { background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius); padding:20px; }
.stat-card .stat-label { font-size:13px; color:var(--text-secondary); margin-bottom:8px; }
.stat-card .stat-value { font-size:28px; font-weight:800; }
.stat-card .stat-sub { font-size:12px; color:var(--text-muted); margin-top:4px; }
.bar-row { display:flex; align-items:center; gap:12px; margin-bottom:14px; }
.bar-label { width:140px; font-size:13px; color:var(--text-secondary); flex-shrink:0; }
.bar-track { flex:1; background:var(--bg-input); border-radius:6px; height:12px; overflow:hidden; }
.bar-fill { height:100%; background:var(--accent); border-radius:6px; transition:width .3s; }
.bar-value { width:30px; text-align:right; font-size:13px; font-weight:600; }
.stats-section-title { font-size:15px; font-weight:700; margin:24px 0 14px; }

/* PLANNING */
.planning-day { border-left:3px solid var(--accent); padding:14px 18px; margin-bottom:14px; background:var(--bg-input); border-radius:0 8px 8px 0; display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; }
.planning-date { font-size:12px; color:var(--text-muted); text-transform:uppercase; margin-bottom:6px; }
.planning-title { font-size:15px; font-weight:700; margin-bottom:4px; }
.planning-meta { font-size:12px; color:var(--text-secondary); }

/* MODAL */
.modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.6); display:none; align-items:center; justify-content:center; z-index:100; padding:20px; }
.modal-overlay.open { display:flex; }
.modal-box { background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius); padding:24px; width:440px; max-width:100%; max-height:90vh; overflow-y:auto; }
.modal-box h3 { margin-bottom:16px; font-size:17px; }
.modal-actions { display:flex; justify-content:flex-end; gap:10px; margin-top:20px; }

@media (max-width:900px) {
  .sidebar { display:none; }
  .form-row { grid-template-columns:1fr; }
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sidebar-group-title" onclick="toggleGroup('assistance', this)">
    <span>❓ ASSISTANCE</span>
    <svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
  </div>
  <div class="sidebar-group-links" id="group-assistance">
    <button class="sidebar-link active" data-view="tickets" onclick="navigateTo('tickets')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18"/></svg>
      Tickets
    </button>
    <button class="sidebar-link" data-view="create-ticket" onclick="navigateTo('create-ticket')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
      Create ticket
    </button>
    <button class="sidebar-link" data-view="problems" onclick="navigateTo('problems')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v4M12 17h.01M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>
      Problems
    </button>
    <button class="sidebar-link" data-view="changes" onclick="navigateTo('changes')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.5 15"/></svg>
      Changes
    </button>
    <button class="sidebar-link" data-view="planning" onclick="navigateTo('planning')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
      Planning
    </button>
    <button class="sidebar-link" data-view="statistics" onclick="navigateTo('statistics')">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/></svg>
      Statistics
    </button>
  </div>

  <hr class="sidebar-divider">

  <div class="sidebar-group-title" onclick="toggleGroup('administration', this)">
    <span>🛡 ADMINISTRATION</span>
    <svg class="chevron rotated" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
  </div>
  <div class="sidebar-group-links collapsed" id="group-administration">
    <button class="sidebar-link" onclick="navigateTo('placeholder','Users', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      Users
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Departments', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 9h1M9 13h1M14 9h1M14 13h1"/></svg>
      Departments
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Roles &amp; Permissions', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      Roles &amp; Permissions
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Categories', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Categories
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Audit Log', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 15h6M9 11h1"/></svg>
      Audit Log
    </button>
  </div>

  <hr class="sidebar-divider">

  <div class="sidebar-group-title" onclick="toggleGroup('setup', this)">
    <span>⚙ SETUP</span>
    <svg class="chevron rotated" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
  </div>
  <div class="sidebar-group-links collapsed" id="group-setup">
    <button class="sidebar-link" onclick="navigateTo('placeholder','General Settings', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 0 1-4 0v-.09A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.55-1H3a2 2 0 0 1 0-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34H9a1.7 1.7 0 0 0 1-1.55V3a2 2 0 0 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87V9a1.7 1.7 0 0 0 1.55 1H21a2 2 0 0 1 0 4h-.09a1.7 1.7 0 0 0-1.55 1z"/></svg>
      General Settings
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Ticket Fields &amp; Forms', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12h6M9 16h6M9 8h1"/><rect x="3" y="4" width="18" height="16" rx="2"/></svg>
      Ticket Fields &amp; Forms
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Notifications', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/></svg>
      Notifications
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Integrations', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 16.98h-5.99c-1.66 0-3.01-1.34-3.01-3s1.34-3 3.01-3H18M6 6.98h6c1.66 0 3 1.34 3 3"/><circle cx="18" cy="6.98" r="3"/><circle cx="6" cy="16.98" r="3"/></svg>
      Integrations
    </button>
    <button class="sidebar-link" onclick="navigateTo('placeholder','Appearance', this)">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20M2 12h20"/></svg>
      Appearance
    </button>
  </div>
</aside>
<!-- MAIN -->
<div class="main-content">
  <div class="topbar">
    <div class="topbar-left">
      <button class="topbar-icon-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg></button>
    </div>
    <div class="topbar-right">
      <span class="badge-system"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.5 15"/></svg> Ticket System</span>
      <button class="btn-logout"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg> Logout</button>
      <button class="topbar-icon-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/></svg></button>
      <button class="topbar-icon-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg></button>
      <div class="avatar">2M</div>
    </div>
  </div>

  <div class="page-body">

    <!-- ==================== TICKETS ==================== -->
    <section class="view active" id="view-tickets">
      <div class="page-header">
        <div class="page-header-left"><h1>Tickets</h1><span class="pill" id="tickets-count-pill">0 open</span></div>
        <div class="header-actions">
          <button class="btn" onclick="toggleArchiveView()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 8v13H3V8M1 3h22v5H1zM10 12h4"/></svg><span id="archive-btn-label">Archive</span></button>
          <button class="btn" onclick="renderTickets()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.5 15"/></svg>Refresh</button>
          <button class="btn btn-primary" onclick="navigateTo('create-ticket')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>New Ticket</button>
        </div>
      </div>
      <div class="toolbar">
        <div class="search-input"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg><input type="text" id="ticket-search" placeholder="Search tickets..." oninput="renderTickets()"></div>
        <select id="ticket-status-filter" onchange="renderTickets()">
          <option value="">All Status</option>
          <option value="Open">Open</option>
          <option value="In Progress">In Progress</option>
          <option value="Resolved">Resolved</option>
          <option value="Closed">Closed</option>
        </select>
        <select id="ticket-dept-filter" onchange="renderTickets()">
          <option value="">All</option>
          <option value="Broadcast">Broadcast</option>
          <option value="IT">IT</option>
          <option value="Production">Production</option>
          <option value="Journalism">Journalism</option>
          <option value="Maintenance">Maintenance</option>
          <option value="HR">HR</option>
        </select>
      </div>
      <div class="card" id="tickets-container"></div>
    </section>

    <!-- ==================== CREATE TICKET ==================== -->
    <section class="view" id="view-create-ticket">
      <div class="page-header">
        <div class="page-header-left"><h1>Create Ticket</h1></div>
        <div class="header-actions"><button class="btn" onclick="navigateTo('tickets')">Back to Tickets</button></div>
      </div>
      <div class="card">
        <form id="create-ticket-form" onsubmit="return handleCreateTicket(event)">
          <div class="form-group"><label>Title</label><input type="text" id="ct-title" required placeholder="Ex: Panne micro plateau JT 20h"></div>
          <div class="form-group"><label>Description</label><textarea id="ct-description" placeholder="Décris le problème en détail..."></textarea></div>
          <div class="form-row">
            <div class="form-group"><label>Department</label>
              <select id="ct-department" required>
                <option value="Broadcast">Broadcast</option>
                <option value="IT">IT</option>
                <option value="Production">Production</option>
                <option value="Journalism">Journalism</option>
                <option value="Maintenance">Maintenance</option>
                <option value="HR">Human Resources</option>
              </select>
            </div>
            <div class="form-group"><label>Priority</label>
              <select id="ct-priority" required>
                <option value="Low">Low</option>
                <option value="Medium" selected>Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Requester</label><input type="text" id="ct-requester" required placeholder="Nom de la personne"></div>
            <div class="form-group"><label>Assignee (optional)</label><input type="text" id="ct-assignee" placeholder="Technicien assigné"></div>
          </div>
          <div class="form-actions">
            <button type="button" class="btn" onclick="navigateTo('tickets')">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Ticket</button>
          </div>
        </form>
      </div>
    </section>

    <!-- ==================== PROBLEMS ==================== -->
    <section class="view" id="view-problems">
      <div class="page-header">
        <div class="page-header-left"><h1>Problems</h1><span class="pill" id="problems-count-pill">0</span></div>
        <div class="header-actions"><button class="btn btn-primary" onclick="openModal('problem')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>New Problem</button></div>
      </div>
      <div class="card" id="problems-container"></div>
    </section>

    <!-- ==================== CHANGES ==================== -->
    <section class="view" id="view-changes">
      <div class="page-header">
        <div class="page-header-left"><h1>Changes</h1><span class="pill" id="changes-count-pill">0</span></div>
        <div class="header-actions"><button class="btn btn-primary" onclick="openModal('change')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>New Change</button></div>
      </div>
      <div class="card" id="changes-container"></div>
    </section>

    <!-- ==================== PLANNING ==================== -->
    <section class="view" id="view-planning">
      <div class="page-header">
        <div class="page-header-left"><h1>Planning</h1><span class="pill" id="planning-count-pill">0</span></div>
        <div class="header-actions"><button class="btn btn-primary" onclick="openModal('planning')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>New Item</button></div>
      </div>
      <div class="card" id="planning-container"></div>
    </section>

    <!-- ==================== STATISTICS ==================== -->
    <section class="view" id="view-statistics">
      <div class="page-header"><div class="page-header-left"><h1>Statistics</h1></div></div>
      <div class="stats-grid" id="stats-cards"></div>
      <div class="card">
        <div class="stats-section-title">Tickets by Department</div>
        <div id="stats-by-department"></div>
        <div class="stats-section-title">Tickets by Status</div>
        <div id="stats-by-status"></div>
        <div class="stats-section-title">Tickets by Priority</div>
        <div id="stats-by-priority"></div>
      </div>
    </section>

  </div>
</div>

<!-- MODAL (Problems / Changes / Planning) -->
<div class="modal-overlay" id="modal-overlay">
  <div class="modal-box">
    <h3 id="modal-title">New Item</h3>
    <div id="modal-body"></div>
    <div class="modal-actions">
      <button class="btn" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitModal()">Save</button>
    </div>
  </div>
</div>

<script>
/* ===================== DATA LAYER ===================== */
const STORAGE_KEY = 'mtv_assistance_data_v1';

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  const fresh = { tickets: [], problems: [], changes: [], planning: [], counters: { ticket: 0, problem: 0, change: 0, planning: 0 } };
  saveData(fresh);
  return fresh;
}
function saveData(data) { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
let DB = loadData();

function nextId(type, prefix) {
  DB.counters[type] = (DB.counters[type] || 0) + 1;
  saveData(DB);
  return prefix + '-' + String(DB.counters[type]).padStart(4, '0');
}

/* ===================== NAVIGATION ===================== */
function toggleGroup(name, titleEl) {
  const links = document.getElementById('group-' + name);
  const chevron = titleEl.querySelector('.chevron');
  links.classList.toggle('collapsed');
  chevron.classList.toggle('rotated');
}

function navigateTo(view, label, el) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));

  if (view === 'placeholder') {
    document.getElementById('view-placeholder').classList.add('active');
    document.getElementById('placeholder-title').textContent = label || 'Coming soon';
    if (el) el.classList.add('active');
    return;
  }

  document.getElementById('view-' + view).classList.add('active');
  const link = el || document.querySelector('.sidebar-link[data-view="' + view + '"]');
  if (link) link.classList.add('active');

  if (view === 'tickets') renderTickets();
  if (view === 'problems') renderProblems();
  if (view === 'changes') renderChanges();
  if (view === 'planning') renderPlanning();
  if (view === 'statistics') renderStatistics();
  if (view === 'create-ticket') document.getElementById('create-ticket-form').reset();
}

/* ===================== TICKETS ===================== */
let showingArchive = false;

function toggleArchiveView() {
  showingArchive = !showingArchive;
  document.getElementById('archive-btn-label').textContent = showingArchive ? 'Back to Active' : 'Archive';
  renderTickets();
}

function badgeStatus(status) {
  const cls = { 'Open': 'status-open', 'In Progress': 'status-in-progress', 'Resolved': 'status-resolved', 'Closed': 'status-closed' }[status] || 'status-open';
  return '<span class="badge ' + cls + '">' + status + '</span>';
}
function badgePriority(p) {
  const cls = { 'Low': 'priority-low', 'Medium': 'priority-medium', 'High': 'priority-high', 'Critical': 'priority-critical' }[p] || 'priority-low';
  return '<span class="badge ' + cls + '">' + p + '</span>';
}

function renderTickets() {
  const search = (document.getElementById('ticket-search').value || '').toLowerCase();
  const statusFilter = document.getElementById('ticket-status-filter').value;
  const deptFilter = document.getElementById('ticket-dept-filter').value;

  let list = DB.tickets.filter(t => showingArchive ? t.status === 'Closed' : t.status !== 'Closed');
  if (search) list = list.filter(t => t.title.toLowerCase().includes(search) || t.id.toLowerCase().includes(search));
  if (statusFilter) list = list.filter(t => t.status === statusFilter);
  if (deptFilter) list = list.filter(t => t.department === deptFilter);

  const openCount = DB.tickets.filter(t => t.status === 'Open' || t.status === 'In Progress').length;
  document.getElementById('tickets-count-pill').textContent = openCount + ' open';

  const container = document.getElementById('tickets-container');
  if (list.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
      <h3>No tickets found</h3>
      <p>${showingArchive ? 'No archived tickets yet' : 'No open tickets yet'}</p>
    </div>`;
    return;
  }

  let rows = list.map(t => `
    <tr>
      <td>${t.id}</td>
      <td>${t.title}</td>
      <td>${t.department}</td>
      <td>${badgePriority(t.priority)}</td>
      <td>${badgeStatus(t.status)}</td>
      <td>${t.requester}</td>
      <td>${t.assignee || '—'}</td>
      <td class="row-actions">
        <select onchange="updateTicketStatus('${t.id}', this.value)" class="btn-sm">
          <option value="Open" ${t.status === 'Open' ? 'selected' : ''}>Open</option>
          <option value="In Progress" ${t.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
          <option value="Resolved" ${t.status === 'Resolved' ? 'selected' : ''}>Resolved</option>
          <option value="Closed" ${t.status === 'Closed' ? 'selected' : ''}>Closed</option>
        </select>
        <button class="btn btn-danger btn-sm" onclick="deleteTicket('${t.id}')">Delete</button>
      </td>
    </tr>`).join('');

  container.innerHTML = `<table class="data-table">
    <thead><tr><th>ID</th><th>Title</th><th>Department</th><th>Priority</th><th>Status</th><th>Requester</th><th>Assignee</th><th>Actions</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

function handleCreateTicket(e) {
  e.preventDefault();
  const ticket = {
    id: nextId('ticket', 'TCK'),
    title: document.getElementById('ct-title').value.trim(),
    description: document.getElementById('ct-description').value.trim(),
    department: document.getElementById('ct-department').value,
    priority: document.getElementById('ct-priority').value,
    requester: document.getElementById('ct-requester').value.trim(),
    assignee: document.getElementById('ct-assignee').value.trim(),
    status: 'Open',
    createdAt: new Date().toISOString()
  };
  DB.tickets.unshift(ticket);
  saveData(DB);
  navigateTo('tickets');
  return false;
}

function updateTicketStatus(id, status) {
  const t = DB.tickets.find(x => x.id === id);
  if (t) { t.status = status; saveData(DB); renderTickets(); }
}
function deleteTicket(id) {
  if (!confirm('Supprimer ce ticket ?')) return;
  DB.tickets = DB.tickets.filter(t => t.id !== id);
  saveData(DB);
  renderTickets();
}

/* ===================== PROBLEMS ===================== */
function renderProblems() {
  document.getElementById('problems-count-pill').textContent = DB.problems.length;
  const container = document.getElementById('problems-container');
  if (DB.problems.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg>
      <h3>No problems found</h3><p>No known problems recorded yet</p></div>`;
    return;
  }
  const rows = DB.problems.map(p => `
    <tr><td>${p.id}</td><td>${p.title}</td><td>${p.impact}</td><td>${badgeStatus(p.status)}</td><td>${p.relatedTicket || '—'}</td>
    <td><button class="btn btn-danger btn-sm" onclick="deleteItem('problems','${p.id}', renderProblems)">Delete</button></td></tr>`).join('');
  container.innerHTML = `<table class="data-table"><thead><tr><th>ID</th><th>Title</th><th>Impact</th><th>Status</th><th>Related Ticket</th><th>Actions</th></tr></thead><tbody>${rows}</tbody></table>`;
}

/* ===================== CHANGES ===================== */
function renderChanges() {
  document.getElementById('changes-count-pill').textContent = DB.changes.length;
  const container = document.getElementById('changes-container');
  if (DB.changes.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.5 15"/></svg>
      <h3>No changes found</h3><p>No scheduled changes yet</p></div>`;
    return;
  }
  const rows = DB.changes.map(c => `
    <tr><td>${c.id}</td><td>${c.title}</td><td>${c.type}</td><td>${c.department}</td><td>${c.scheduledDate}</td><td>${badgeStatus(c.status)}</td>
    <td><button class="btn btn-danger btn-sm" onclick="deleteItem('changes','${c.id}', renderChanges)">Delete</button></td></tr>`).join('');
  container.innerHTML = `<table class="data-table"><thead><tr><th>ID</th><th>Title</th><th>Type</th><th>Department</th><th>Scheduled</th><th>Status</th><th>Actions</th></tr></thead><tbody>${rows}</tbody></table>`;
}

/* ===================== PLANNING ===================== */
function renderPlanning() {
  document.getElementById('planning-count-pill').textContent = DB.planning.length;
  const container = document.getElementById('planning-container');
  if (DB.planning.length === 0) {
    container.innerHTML = `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
      <h3>No planning items</h3><p>Nothing scheduled yet</p></div>`;
    return;
  }
  const sorted = [...DB.planning].sort((a, b) => a.date.localeCompare(b.date));
  container.innerHTML = sorted.map(p => `
    <div class="planning-day">
      <div>
        <div class="planning-date">${p.date} · ${p.type}</div>
        <div class="planning-title">${p.title}</div>
        <div class="planning-meta">${p.department}${p.notes ? ' — ' + p.notes : ''}</div>
      </div>
      <button class="btn btn-danger btn-sm" onclick="deleteItem('planning','${p.id}', renderPlanning)">Delete</button>
    </div>`).join('');
}

/* ===================== GENERIC DELETE ===================== */
function deleteItem(collection, id, renderFn) {
  if (!confirm('Supprimer cet élément ?')) return;
  DB[collection] = DB[collection].filter(x => x.id !== id);
  saveData(DB);
  renderFn();
}

/* ===================== STATISTICS ===================== */
function renderStatistics() {
  const tickets = DB.tickets;
  const total = tickets.length;
  const open = tickets.filter(t => t.status === 'Open').length;
  const inProgress = tickets.filter(t => t.status === 'In Progress').length;
  const resolved = tickets.filter(t => t.status === 'Resolved').length;
  const critical = tickets.filter(t => t.priority === 'Critical').length;

  document.getElementById('stats-cards').innerHTML = `
    <div class="stat-card"><div class="stat-label">Total Tickets</div><div class="stat-value">${total}</div></div>
    <div class="stat-card"><div class="stat-label">Open</div><div class="stat-value" style="color:var(--status-open)">${open}</div></div>
    <div class="stat-card"><div class="stat-label">In Progress</div><div class="stat-value" style="color:var(--status-progress)">${inProgress}</div></div>
    <div class="stat-card"><div class="stat-label">Resolved</div><div class="stat-value" style="color:var(--status-resolved)">${resolved}</div></div>
    <div class="stat-card"><div class="stat-label">Critical Priority</div><div class="stat-value" style="color:var(--priority-critical)">${critical}</div></div>
  `;

  renderBarGroup('stats-by-department', groupCount(tickets, 'department'), total);
  renderBarGroup('stats-by-status', groupCount(tickets, 'status'), total);
  renderBarGroup('stats-by-priority', groupCount(tickets, 'priority'), total);
}

function groupCount(list, field) {
  const counts = {};
  list.forEach(item => { counts[item[field]] = (counts[item[field]] || 0) + 1; });
  return counts;
}

function renderBarGroup(containerId, counts, total) {
  const container = document.getElementById(containerId);
  const keys = Object.keys(counts);
  if (keys.length === 0) { container.innerHTML = '<p style="color:var(--text-muted);font-size:13px;">No data yet</p>'; return; }
  container.innerHTML = keys.map(key => {
    const val = counts[key];
    const pct = total ? Math.round((val / total) * 100) : 0;
    return `<div class="bar-row"><div class="bar-label">${key}</div><div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div><div class="bar-value">${val}</div></div>`;
  }).join('');
}

/* ===================== MODAL (Problems / Changes / Planning) ===================== */
let currentModalType = null;

function openModal(type) {
  currentModalType = type;
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body');

  if (type === 'problem') {
    title.textContent = 'New Problem';
    body.innerHTML = `
      <div class="form-group"><label>Title</label><input type="text" id="m-title"></div>
      <div class="form-group"><label>Impact</label>
        <select id="m-impact"><option>Low</option><option selected>Medium</option><option>High</option></select></div>
      <div class="form-group"><label>Related Ticket ID (optional)</label><input type="text" id="m-related"></div>`;
  } else if (type === 'change') {
    title.textContent = 'New Change';
    body.innerHTML = `
      <div class="form-group"><label>Title</label><input type="text" id="m-title"></div>
      <div class="form-group"><label>Type</label>
        <select id="m-type"><option>Standard</option><option>Normal</option><option>Emergency</option></select></div>
      <div class="form-group"><label>Department</label>
        <select id="m-department"><option>Broadcast</option><option>IT</option><option>Production</option><option>Journalism</option><option>Maintenance</option><option>HR</option></select></div>
      <div class="form-group"><label>Scheduled Date</label><input type="date" id="m-date"></div>`;
  } else if (type === 'planning') {
    title.textContent = 'New Planning Item';
    body.innerHTML = `
      <div class="form-group"><label>Title</label><input type="text" id="m-title"></div>
      <div class="form-group"><label>Date</label><input type="date" id="m-date"></div>
      <div class="form-group"><label>Type</label>
        <select id="m-type"><option>Maintenance</option><option>Meeting</option><option>Deployment</option><option>Training</option></select></div>
      <div class="form-group"><label>Department</label>
        <select id="m-department"><option>Broadcast</option><option>IT</option><option>Production</option><option>Journalism</option><option>Maintenance</option><option>HR</option></select></div>
      <div class="form-group"><label>Notes (optional)</label><input type="text" id="m-notes"></div>`;
  }
  document.getElementById('modal-overlay').classList.add('open');
}

function closeModal() { document.getElementById('modal-overlay').classList.remove('open'); currentModalType = null; }

function submitModal() {
  const title = document.getElementById('m-title').value.trim();
  if (!title) { alert('Le titre est requis'); return; }

  if (currentModalType === 'problem') {
    DB.problems.unshift({ id: nextId('problem', 'PRB'), title, impact: document.getElementById('m-impact').value, status: 'Open', relatedTicket: document.getElementById('m-related').value.trim(), createdAt: new Date().toISOString() });
    renderProblems();
  } else if (currentModalType === 'change') {
    DB.changes.unshift({ id: nextId('change', 'CHG'), title, type: document.getElementById('m-type').value, department: document.getElementById('m-department').value, scheduledDate: document.getElementById('m-date').value || '—', status: 'Planned', createdAt: new Date().toISOString() });
    renderChanges();
  } else if (currentModalType === 'planning') {
    DB.planning.unshift({ id: nextId('planning', 'PLN'), title, date: document.getElementById('m-date').value || '—', type: document.getElementById('m-type').value, department: document.getElementById('m-department').value, notes: document.getElementById('m-notes').value.trim() });
    renderPlanning();
  }
  saveData(DB);
  closeModal();
}

/* ===================== INIT ===================== */
renderTickets();
</script>
</body>
</html>