<?php
session_start();

include "C:\\xampp\\htdocs\\test\\db.php";

$username = $_POST['nom'];
$password = $_POST['password'];

$sql = "SELECT * FROM utilisateur WHERE username='$username' AND password='$password'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $_SESSION['username'] = $username;

    header("Location: dashboard.php");
    exit();

} else {

    echo "Nom d'utilisateur ou mot de passe incorrect.";

}

$conn->close();
?>